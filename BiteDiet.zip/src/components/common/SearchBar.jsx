import { Search } from "lucide-react";

function SearchBar() {
  return (
    <div className="max-w-4xl mx-auto px-6 -mt-8 relative z-10">
      <div className="bg-white rounded-full shadow-xl flex items-center px-5 py-4">

        <Search className="text-green-600" size={22} />

        <input
          type="text"
          placeholder="Search healthy recipes..."
          className="w-full ml-4 outline-none text-lg"
        />

      </div>
    </div>
  );
}

export default SearchBar;