function Categories() {
  const categories = [
    "🥗 Breakfast",
    "🍛 Lunch",
    "🍲 Dinner",
    "🥤 Snacks",
    "🍹 Drinks",
  ];

  return (
    <section className="max-w-7xl mx-auto px-6 py-10">
      <h2 className="text-3xl font-bold text-green-700 mb-6">
        Categories
      </h2>

      <div className="flex flex-wrap gap-4">
        {categories.map((item) => (
          <button
            key={item}
            className="bg-green-100 hover:bg-green-600 hover:text-white px-6 py-3 rounded-full transition font-medium"
          >
            {item}
          </button>
        ))}
      </div>
    </section>
  );
}

export default Categories;