function Hero() {
  return (
    <section className="bg-gradient-to-r from-green-600 to-green-400 text-white">
      <div className="max-w-7xl mx-auto px-6 py-20">

        <h1 className="text-5xl md:text-7xl font-bold">
          Eat Healthy,
        </h1>

        <h2 className="text-4xl md:text-6xl mt-3 font-bold">
          Live Better 🌿
        </h2>

        <p className="mt-6 text-lg md:text-xl max-w-2xl">
          Personalized healthy recipe recommendations for
          Diabetic, BP and Normal users.
        </p>

        <button className="mt-8 bg-white text-green-700 px-8 py-4 rounded-full font-semibold hover:scale-105 transition">
          Explore Recipes
        </button>

      </div>
    </section>
  );
}

export default Hero;