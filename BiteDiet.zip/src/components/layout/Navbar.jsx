function Navbar() {
  return (
    <nav style={{ padding: "20px", background: "green", color: "white" }}>
      BiteDiet Navbar
    </nav>
  );
}

export default Navbar;