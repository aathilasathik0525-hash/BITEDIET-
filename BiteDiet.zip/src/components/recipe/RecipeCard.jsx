function RecipeCard({ recipe }) {
  return (
    <div className="bg-white rounded-3xl shadow-lg overflow-hidden hover:shadow-2xl hover:-translate-y-2 transition duration-300">

      <img
        src={recipe.image}
        alt={recipe.name}
        className="h-56 w-full object-cover"
      />

      <div className="p-5">

        <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm">
          {recipe.disease}
        </span>

        <h2 className="text-2xl font-bold mt-4">
          {recipe.name}
        </h2>

        <p className="text-gray-500 mt-2">
          {recipe.description}
        </p>

        <div className="flex justify-between mt-4 text-sm text-gray-600">
          <span>🔥 {recipe.calories} Cal</span>
          <span>⏱ {recipe.time}</span>
        </div>

        <button className="w-full mt-6 bg-green-600 hover:bg-green-700 text-white py-3 rounded-xl">
          View Recipe
        </button>

      </div>

    </div>
  );
}

export default RecipeCard;