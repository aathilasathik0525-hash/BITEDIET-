const bpRecipes = [
  {
    id: 1,
    name: "Vegetable Soup",
    category: "Dinner",
    calories: 160,
    time: "25 mins",
    image: "https://images.unsplash.com/photo-1547592180-85f173990554",
    description: "Low sodium healthy soup.",
    disease: "Blood Pressure",
  },
  {
    id: 2,
    name: "Brown Rice Bowl",
    category: "Lunch",
    calories: 280,
    time: "30 mins",
    image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd",
    description: "Balanced meal with vegetables.",
    disease: "Blood Pressure",
  },
];

export default bpRecipes;