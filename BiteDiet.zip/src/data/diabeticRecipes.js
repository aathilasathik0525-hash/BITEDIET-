const diabeticRecipes = [
  {
    id: 1,
    name: "Vegetable Salad",
    category: "Lunch",
    calories: 180,
    time: "20 mins",
    image: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c",
    description: "Low sugar healthy vegetable salad.",
    disease: "Diabetes",
  },
  {
    id: 2,
    name: "Grilled Fish",
    category: "Dinner",
    calories: 250,
    time: "30 mins",
    image: "https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2",
    description: "Protein-rich grilled fish with vegetables.",
    disease: "Diabetes",
  },
  {
    id: 3,
    name: "Oats Porridge",
    category: "Breakfast",
    calories: 150,
    time: "15 mins",
    image: "https://images.unsplash.com/photo-1517673400267-0251440c45dc",
    description: "Fiber-rich breakfast for blood sugar control.",
    disease: "Diabetes",
  },
];

export default diabeticRecipes;