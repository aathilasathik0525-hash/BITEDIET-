import diabeticRecipes from "./diabeticRecipes";
import bpRecipes from "./bpRecipes";
import normalRecipes from "./normalRecipes";

const allRecipes = [
  ...diabeticRecipes,
  ...bpRecipes,
  ...normalRecipes,
];

export default allRecipes;