const normalRecipes = [
  {
    id: 1,
    name: "Chicken Sandwich",
    category: "Breakfast",
    calories: 320,
    time: "15 mins",
    image: "https://images.unsplash.com/photo-1553909489-cd47e0907980",
    description: "Healthy chicken sandwich.",
    disease: "Normal",
  },
  {
    id: 2,
    name: "Fruit Smoothie",
    category: "Drinks",
    calories: 140,
    time: "10 mins",
    image: "https://images.unsplash.com/photo-1505252585461-04db1eb84625",
    description: "Refreshing fruit smoothie.",
    disease: "Normal",
  },
];

export default normalRecipes;