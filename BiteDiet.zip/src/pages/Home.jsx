import Navbar from "../components/layout/Navbar";

function Home() {
  return (
    <>
      <Navbar />
      <h1>Home Working</h1>
    </>
  );
}

export default Home;