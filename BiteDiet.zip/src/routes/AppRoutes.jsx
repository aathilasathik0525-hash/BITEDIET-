import { BrowserRouter, Routes, Route } from "react-router-dom";
import PatientSelection from "../pages/PatientSelection";

function AppRoutes() {
  return (
    <BrowserRouter>
      <Routes>
       <Route
  path="/home"
  element={<h1 style={{ fontSize: "40px" }}>HOME WORKING</h1>}
/>
      </Routes>
    </BrowserRouter>
  );
}

export default AppRoutes;